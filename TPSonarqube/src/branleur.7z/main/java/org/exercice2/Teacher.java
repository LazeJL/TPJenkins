package org.exercice2;

public interface Teacher {
    void teach(Student student);
}